﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Student: Deivid Santos
 * ID: 100731640
 * Date: 2020-07-31
 * 
 * Description: A client has contracted your company to create a text editor. 
 * It may seem silly to create another basic text editor, but it is anticipated 
 * that if this is done well it will become part of a larger application.
 * 
 * */
namespace TextEditorProject
{
    public partial class frmTextEditor : Form
    {
        public frmTextEditor()
        {
            InitializeComponent();
        }

        private void frmTextEditor_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Create a new file by ereasing whats writen on the text box 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Clear();
        }
        /// <summary>
        /// Exit the application 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// Open a save .txt file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdObject = new OpenFileDialog();
            ofdObject.Filter = "Text Files (.txt)|*.txt";
            ofdObject.Title = "Open File...";
            if (ofdObject.ShowDialog() == DialogResult.OK) ;
            {
                System.IO.StreamReader streamReaderObject = new System.IO.StreamReader(ofdObject.FileName);
                richTxtBoxUserInput.Text = streamReaderObject.ReadToEnd();
                streamReaderObject.Close();
            }

        }
        /// <summary>
        /// Save the exitent text on the text box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialogObject = new SaveFileDialog();
            saveDialogObject.Filter = "Text Files (.txt)|*.txt";
            saveDialogObject.Title = "Save File...";
            if (saveDialogObject.ShowDialog() == DialogResult.OK) ;
            {
                System.IO.StreamWriter streamWriterObject = new System.IO.StreamWriter(saveDialogObject.FileName);
                streamWriterObject.Write(richTxtBoxUserInput.Text);
                streamWriterObject.Close();
            }
        }
        /// <summary>
        /// Undo the action when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Undo();
        }
        /// <summary>
        /// redo the action when clicked 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Redo();
        }
        /// <summary>
        /// cut the select item when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Cut(); //call the cut function and cut the selected text
        }
        /// <summary>
        /// copy the selected item when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Copy(); // call the copy function and copy the text selected
        }
        /// <summary>
        /// paste into the text box when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.Paste(); //call the paste function and paste the text into the textbox
        }
        /// <summary>
        /// select all texts when clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTxtBoxUserInput.SelectAll(); //call the select all function and select all texts
        }
        /// <summary>
        /// Open a text box with the info about the system 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NETD-2202\n" + //Open a textbox outputing a message to the user
                "LAB5\n" +
                "D. Santos");

        }
    }
}
